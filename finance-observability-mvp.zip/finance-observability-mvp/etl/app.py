import os
import time
import threading
from datetime import datetime, timezone
from decimal import Decimal

import psycopg2
import requests
import uvicorn
from fastapi import FastAPI
from prometheus_client import Counter, Gauge, Histogram, generate_latest, CONTENT_TYPE_LATEST
from starlette.responses import Response

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://finance:finance@localhost:5432/finance")
SEC_USER_AGENT = os.getenv("SEC_USER_AGENT", "finance-observability-mvp contact@example.com")
COMPANIES = [c.strip().upper() for c in os.getenv("COMPANIES", "AAPL,MSFT,AMZN").split(",") if c.strip()]
LOAD_INTERVAL_SECONDS = int(os.getenv("LOAD_INTERVAL_SECONDS", "3600"))

TICKER_CIK = {
    "AAPL": "0000320193",
    "MSFT": "0000789019",
    "AMZN": "0001018724",
    "GOOGL": "0001652044",
    "META": "0001326801",
    "TSLA": "0001318605",
    "NVDA": "0001045810",
}

CONCEPTS = {
    "Assets": ["Assets"],
    "Liabilities": ["Liabilities"],
    "Equity": ["StockholdersEquity", "StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest"],
    "Revenue": ["RevenueFromContractWithCustomerExcludingAssessedTax", "Revenues"],
    "NetIncome": ["NetIncomeLoss"],
    "Cash": ["CashAndCashEquivalentsAtCarryingValue", "CashCashEquivalentsRestrictedCashAndRestrictedCashEquivalents"],
}

LOAD_SUCCESS = Counter("finance_etl_load_success_total", "Successful ETL loads")
LOAD_FAILURE = Counter("finance_etl_load_failure_total", "Failed ETL loads")
DQ_FAILURES = Gauge("finance_dq_failures", "Current finance DQ failures")
DQ_WARNINGS = Gauge("finance_dq_warnings", "Current finance DQ warnings")
LOAD_LATENCY = Histogram("finance_etl_load_latency_seconds", "ETL load latency")
FACT_ROWS = Gauge("finance_fact_rows", "Rows in company_facts")
FRESHNESS_HOURS = Gauge("finance_data_freshness_hours", "Hours since latest filed date", ["ticker"])

app = FastAPI(title="Finance Observability MVP")


def db():
    return psycopg2.connect(DATABASE_URL)


def upsert_fact(cur, ticker, cik, fy, fp, form, filed, concept, value, unit, frame):
    cur.execute(
        """
        INSERT INTO company_facts
        (ticker,cik,fiscal_year,fiscal_period,form,filed_at,concept,value,unit,frame)
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
        ON CONFLICT (ticker, fiscal_year, fiscal_period, form, concept, unit)
        DO UPDATE SET loaded_at=now(), filed_at=EXCLUDED.filed_at, value=EXCLUDED.value, frame=EXCLUDED.frame
        """,
        (ticker, cik, fy, fp, form, filed, concept, value, unit, frame),
    )


def sec_companyfacts(cik):
    url = f"https://data.sec.gov/api/xbrl/companyfacts/CIK{cik}.json"
    r = requests.get(url, headers={"User-Agent": SEC_USER_AGENT, "Accept-Encoding": "gzip, deflate"}, timeout=30)
    r.raise_for_status()
    return r.json()


def extract_sec_facts(ticker):
    cik = TICKER_CIK.get(ticker)
    if not cik:
        return []
    data = sec_companyfacts(cik)
    facts = data.get("facts", {}).get("us-gaap", {})
    rows = []
    for canonical, variants in CONCEPTS.items():
        found = None
        for concept in variants:
            if concept in facts:
                found = concept
                break
        if not found:
            continue
        units = facts[found].get("units", {})
        for unit, entries in units.items():
            for e in entries:
                if e.get("form") not in {"10-K", "10-Q"}:
                    continue
                if not e.get("fy") or not e.get("fp") or e.get("val") is None:
                    continue
                rows.append({
                    "ticker": ticker,
                    "cik": cik,
                    "fy": int(e.get("fy")),
                    "fp": e.get("fp"),
                    "form": e.get("form"),
                    "filed": e.get("filed"),
                    "concept": canonical,
                    "value": Decimal(str(e.get("val"))),
                    "unit": unit,
                    "frame": e.get("frame"),
                })
    return rows[-500:]


def insert_sample_data(cur):
    sample = [
        ("AAPL", "0000320193", 2023, "FY", "10-K", "2023-11-03", "Assets", 352583000000, "USD", "CY2023"),
        ("AAPL", "0000320193", 2023, "FY", "10-K", "2023-11-03", "Liabilities", 290437000000, "USD", "CY2023"),
        ("AAPL", "0000320193", 2023, "FY", "10-K", "2023-11-03", "Equity", 62146000000, "USD", "CY2023"),
        ("AAPL", "0000320193", 2023, "FY", "10-K", "2023-11-03", "Revenue", 383285000000, "USD", "CY2023"),
        ("MSFT", "0000789019", 2023, "FY", "10-K", "2023-07-27", "Assets", 411976000000, "USD", "CY2023"),
        ("MSFT", "0000789019", 2023, "FY", "10-K", "2023-07-27", "Liabilities", 205753000000, "USD", "CY2023"),
        ("MSFT", "0000789019", 2023, "FY", "10-K", "2023-07-27", "Equity", 206223000000, "USD", "CY2023"),
        ("MSFT", "0000789019", 2023, "FY", "10-K", "2023-07-27", "Revenue", 211915000000, "USD", "CY2023"),
    ]
    for row in sample:
        upsert_fact(cur, *row)


def run_dq(cur):
    cur.execute("DELETE FROM dq_results WHERE created_at < now() - interval '7 days'")
    cur.execute("SELECT DISTINCT ticker FROM company_facts")
    tickers = [r[0] for r in cur.fetchall()]
    failures = 0
    warnings = 0
    for ticker in tickers:
        checks = []
        cur.execute("SELECT count(*) FROM company_facts WHERE ticker=%s", (ticker,))
        row_count = cur.fetchone()[0]
        checks.append(("minimum_fact_rows", "high", "PASS" if row_count >= 4 else "FAIL", f"rows={row_count}"))

        cur.execute("SELECT max(filed_at) FROM company_facts WHERE ticker=%s", (ticker,))
        latest_filed = cur.fetchone()[0]
        if latest_filed:
            age_h = (datetime.now(timezone.utc).date() - latest_filed).days * 24
            FRESHNESS_HOURS.labels(ticker=ticker).set(age_h)
            status = "WARN" if age_h > 24 * 540 else "PASS"
            checks.append(("freshness_max_18_months", "medium", status, f"latest_filed={latest_filed}"))
        else:
            checks.append(("freshness_max_18_months", "medium", "FAIL", "no filed_at"))

        cur.execute("""
            WITH latest AS (
              SELECT fiscal_year, fiscal_period, form
              FROM company_facts WHERE ticker=%s AND concept='Assets'
              ORDER BY fiscal_year DESC LIMIT 1
            ), pivot AS (
              SELECT concept, max(value) value FROM company_facts f
              JOIN latest l USING (fiscal_year, fiscal_period, form)
              WHERE f.ticker=%s AND concept IN ('Assets','Liabilities','Equity')
              GROUP BY concept
            ) SELECT
              max(value) FILTER (WHERE concept='Assets'),
              max(value) FILTER (WHERE concept='Liabilities'),
              max(value) FILTER (WHERE concept='Equity')
            FROM pivot
        """, (ticker, ticker))
        assets, liabilities, equity = cur.fetchone()
        if assets and liabilities and equity:
            diff = abs(Decimal(assets) - Decimal(liabilities) - Decimal(equity))
            tolerance = max(Decimal(1000000), abs(Decimal(assets)) * Decimal("0.005"))
            status = "PASS" if diff <= tolerance else "FAIL"
            checks.append(("accounting_equation", "critical", status, f"assets-liabilities-equity={diff}"))
        else:
            checks.append(("accounting_equation", "critical", "WARN", "missing one of Assets/Liabilities/Equity"))

        cur.execute("SELECT count(*) FROM company_facts WHERE ticker=%s AND value IS NULL", (ticker,))
        nulls = cur.fetchone()[0]
        checks.append(("value_not_null", "critical", "PASS" if nulls == 0 else "FAIL", f"nulls={nulls}"))

        for check_name, severity, status, details in checks:
            if status == "FAIL": failures += 1
            if status == "WARN": warnings += 1
            cur.execute(
                "INSERT INTO dq_results(ticker, check_name, severity, status, details) VALUES (%s,%s,%s,%s,%s)",
                (ticker, check_name, severity, status, details),
            )
    DQ_FAILURES.set(failures)
    DQ_WARNINGS.set(warnings)


def load_once():
    start = time.time()
    try:
        with db() as conn:
            with conn.cursor() as cur:
                loaded = 0
                for ticker in COMPANIES:
                    try:
                        rows = extract_sec_facts(ticker)
                    except Exception as exc:
                        print(f"SEC load failed for {ticker}: {exc}; falling back if needed", flush=True)
                        rows = []
                    for r in rows:
                        upsert_fact(cur, r["ticker"], r["cik"], r["fy"], r["fp"], r["form"], r["filed"], r["concept"], r["value"], r["unit"], r["frame"])
                        loaded += 1
                if loaded == 0:
                    insert_sample_data(cur)
                run_dq(cur)
                cur.execute("SELECT count(*) FROM company_facts")
                FACT_ROWS.set(cur.fetchone()[0])
        LOAD_SUCCESS.inc()
    except Exception as exc:
        LOAD_FAILURE.inc()
        print(f"ETL failed: {exc}", flush=True)
    finally:
        LOAD_LATENCY.observe(time.time() - start)


def loop():
    while True:
        load_once()
        time.sleep(LOAD_INTERVAL_SECONDS)


@app.get("/")
def root():
    return {"status": "ok", "companies": COMPANIES}

@app.post("/load")
def trigger_load():
    load_once()
    return {"status": "load completed"}

@app.get("/health")
def health():
    return {"status": "healthy"}

@app.get("/metrics")
def metrics():
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)

if __name__ == "__main__":
    threading.Thread(target=loop, daemon=True).start()
    uvicorn.run(app, host="0.0.0.0", port=8000)
