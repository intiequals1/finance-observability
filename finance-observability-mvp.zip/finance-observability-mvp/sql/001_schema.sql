CREATE TABLE IF NOT EXISTS company_facts (
  id BIGSERIAL PRIMARY KEY,
  loaded_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  ticker TEXT NOT NULL,
  cik TEXT NOT NULL,
  fiscal_year INT NOT NULL,
  fiscal_period TEXT NOT NULL,
  form TEXT NOT NULL,
  filed_at DATE,
  concept TEXT NOT NULL,
  value NUMERIC,
  unit TEXT,
  frame TEXT,
  UNIQUE(ticker, fiscal_year, fiscal_period, form, concept, unit)
);

CREATE TABLE IF NOT EXISTS dq_results (
  id BIGSERIAL PRIMARY KEY,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  ticker TEXT NOT NULL,
  check_name TEXT NOT NULL,
  severity TEXT NOT NULL,
  status TEXT NOT NULL,
  details TEXT
);

CREATE INDEX IF NOT EXISTS idx_company_facts_ticker_year ON company_facts(ticker, fiscal_year);
CREATE INDEX IF NOT EXISTS idx_dq_results_created ON dq_results(created_at DESC);
